
<div class="container">
      <div class="col-lg-12 grid-margin stretch-card mt-2">
        <div class="card">
            <div class="car-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tr>
                            <th>Date</th>
                            <th>Description</th>
                            <th>Type</th>
                            <th>Credit</th>
                            <th>Debit</th>
                        </tr>
                        <tr>
                            <td>01-04-2024	</td>
                            <td>SID:1, Name: Lenovo, Qty: 1, Discount: 571.2, Unit Price: 27988.8 , Extra Added: , Extra Discount: , Trans. Mode:cash	</td>
                            <td>sale</td>
                            <td>33664.94	</td>
                            <td></td>
                        </tr>

                        <tr>
                            <td>01-04-2024	</td>
                            <td>PID: 2, Name: Lenovo, Description: ABC, Units: 2, Price per Unit Rs. 20000	</td>
                            <td>purchase</td>
                            <td></td>
                            <td>40000</td>
                        </tr>

                        <tr>
                            <td>01-04-2024	</td>
                            <td>PID: 1, Name: Lenovo, Description: ABC, Units: 2, Price per Unit Rs. 20000	</td>
                            <td>purchase</td>
                            <td></td>
                            <td>40000</td>
                        </tr>
                        <tr>
                            <th>&nbsp;</th>
                            <th>&nbsp;</th>
                            <th>Total</th>
                            <th>33664.94</th>
                            <th>80000</th>
                          </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
