<?php $__env->startSection('content'); ?>
<!-- container-scroller start -->
<div class="container-scroller">
    <?php echo $__env->make('admin.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- page-body-wrapper start -->
    <div class="container-fluid page-body-wrapper">
        <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- main-panel start -->
        <div class="main-panel">
            <!-- content-wrapper start -->
            <div class="content-wrapper">
                <?php echo $__env->yieldContent('panel'); ?>
            </div>
            <!-- content-wrapper ends -->
            <?php echo $__env->make('admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StoreKeeper\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>