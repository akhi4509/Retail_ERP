<?php $__env->startSection('panel'); ?>
<div class="container">
    <div class="title d-flex justify-content-between align-items-end">
        <div class="col-md-6">
            <h3>Admin Setting</h3>
        </div>
        <div class="col-md-6 d-flex justify-content-end align-items-end">
            <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-primary">
                <div class="d-flex align-items-end">
                    <i class="mdi mdi-a-left-bold"></i>
                    <span>Back</span>
                </div>
            </a>
        </div>
    </div>
</div>

<div class="card mt-2">
    <div class="card-body">
        
            <form action="<?php echo e(route('settings.store')); ?>" name="settings" method="post">
                <?php echo e(csrf_field()); ?>

                
            <div class="row">
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="bname">Business Name</label>
                        <input type="text" class="form-control" id="bname" name="business_name" value="<?php echo e(old('business_name')); ?>" >
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="baddr">Business Address</label>
                        <input type="text" class="form-control" id="baddr" name="business_address" value="<?php echo e(old('business_address')); ?>" >
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="phone">Business Phone No</label>
                        <input type="text" class="form-control" id="phone" name="business_phone_no"value="<?php echo e(old('business_phone_no')); ?>" >
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="account">GST No</label>
                        <input type="text" class="form-control" id="account" name="gst_no" value="<?php echo e(old('gst_no')); ?>" >
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="profit">Business Profit By Percent</label>
                        <input type="text" class="form-control" id="profit" name="sales_profit" value="<?php echo e(old('sales_profit')); ?>" >
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="discount">Discount by %</label>
                        <input type="text" class="form-control" id="discount" name="discount" value="<?php echo e(old('discount')); ?>" >
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="cgst">CGST by %</label>
                        <input type="text" class="form-control" id="cgst" name="cgst" value="<?php echo e(old('cgst')); ?>" >
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12">
                    <div class="form-group">
                        <label for="sgst">SGST by %</label>
                        <input type="text" class="form-control" id="sgst" name="sgst" value="<?php echo e(old('sgst')); ?>" >
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8"></div>
                <div class="col-md-2">
                    <div class="form-group text-end">
                        <button type="submit" class="btn btn-primary">Save Settings</button>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group text-end">
                        <button type="submit" class="btn btn-success"><a ref="<?php echo e(url('settings/1/edit')); ?>">Edit Settings</a></button>
                    </div>
                </div>
            </div>
           
           
        </form>
</div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StoreKeeper\resources\views/admin/setting/settings.blade.php ENDPATH**/ ?>