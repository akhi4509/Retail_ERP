<table class="table table-responsive table-striped table-bordered">
  <thead>
    <tr>
      <th class="col-xs-2">Entry Date</th>
      <th class="col-xs-6">Returns Details</th>
      <th class="col-xs-1">Units</th>
      <th class="col-xs-3">Total Amount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td class="text-center">
          <h4></h4>
          <div class="row">
            <div class="col-xs-12">
              <div class="btn-group btn-group-justified">
                <a href="" class="btn btn-success btn-sm btn-block">Print View</a>
              </div>
            </div>

        </div>
        </td>
        <td>
          <p>Return ID: 123, Ref No: </p>

            <h6>PID:, Name:, Qty:, Price:, ST:, Disc:, </h6>

          <p>
            % CGST Rs./-, % SGST Rs. /-, % Discount Rs. /-
          </p>
        </td>
        <td class="text-center">
          <h3></h3>
        </td>
        <td>
          <h4>Total Amount Rs. /-</h4>
        </td>
      </tr>

  {{-- <tr>
    <td class="text-center">
      <h3>12-12-2016</h3>
      <div class="btn-group btn-group-justified">
        <a href="" class="btn btn-primary btn-sm">view</a>
        <a href="" class="btn btn-danger btn-sm">Delete</a>
      </div>
    </td>
    <td>
      <h4>Product Title</h4>
      <p>Here will be goes product details.</p>
      <p><strong>Rs 200/-</strong> per unit cost</p>
    </td>
    <td class="text-center">
      <h3>12</h3>
    </td>
    <td>
      <h2>Rs. 2000/-</h2>
    </td>
  </tr> --}}

  </tbody>
</table>
